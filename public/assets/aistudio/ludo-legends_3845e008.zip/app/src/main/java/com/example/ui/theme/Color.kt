package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Personality: High-craft analog board room with deep navy felt and warm cream boxwood board.
// One Visual Idea: Sculpted turned-wood lacquer pawns with anatomical lathe-turned geometry and true 3D perspective ivory dice.
// Reference Apps: Linear and Chess.com / Alto's Adventure.

// Exact User Color Specifications
// Main background: #080F24
val SurfaceBackground = Color(0xFF080F24)
// Secondary background: #101B35
val SurfacePanel = Color(0xFF101B35)
val SurfaceElevated = Color(0xFF162544)
val SurfaceSubtle = Color(0xFF0C142B)

// Card border: #263858
val BorderHairline = Color(0xFF263858)
val BorderActive = Color(0xFF3B5285)

// Typography Text Tones
// Primary text: #FFFFFF
val TextPrimary = Color(0xFFFFFFFF)
// Secondary text: #A9B5CB
val TextSecondary = Color(0xFFA9B5CB)
val TextMuted = Color(0xFF6B7A99)

// Primary accent: #F5C928
val AccentPrimary = Color(0xFFF5C928)
val AccentPrimaryHover = Color(0xFFE5B920)

// Safe zones & stars: #E5B93B
val StarGold = Color(0xFFE5B93B)

// Board background: #FFFDF5
val CreamBoardSurface = Color(0xFFFFFDF5)
val CreamTileSurface = Color(0xFFFFFDF5)
// Grid lines: #D8D5C8
val CreamTileBorder = Color(0xFFD8D5C8)

// Exact Traditional Player Colours:
// Red: #E53935
val LudoRed = Color(0xFFE53935)
val LudoRedSurface = Color(0xFFFDE8E8)
val LudoRedDark = Color(0xFFB71C1C)

// Green: #159B55
val LudoGreen = Color(0xFF159B55)
val LudoGreenSurface = Color(0xFFE6F6ED)
val LudoGreenDark = Color(0xFF0D6837)

// Yellow: #F5C928
val LudoYellow = Color(0xFFF5C928)
val LudoYellowSurface = Color(0xFFFEF9E6)
val LudoYellowDark = Color(0xFFB78900)

// Blue: #2878D0
val LudoBlue = Color(0xFF2878D0)
val LudoBlueSurface = Color(0xFFE8F2FC)
val LudoBlueDark = Color(0xFF154E94)
