package com.example.ludo.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ludo.model.BotDifficulty
import com.example.ludo.model.Player
import com.example.ludo.model.PlayerColor
import com.example.ui.theme.AccentPrimary
import com.example.ui.theme.BorderActive
import com.example.ui.theme.BorderHairline
import com.example.ui.theme.StarGold
import com.example.ui.theme.SurfaceBackground
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.SurfacePanel
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.Typography

/**
 * Play With Computer setup screen:
 * Allows configuring total player count (1-3 bots), bot difficulty (Easy/Medium/Hard),
 * player name, and user color selection.
 */
@Composable
fun BotSetupScreen(
    initialUserName: String,
    onBackClick: () -> Unit,
    onStartGame: (List<Player>) -> Unit
) {
    var totalPlayers by remember { mutableIntStateOf(4) }
    var selectedDifficulty by remember { mutableStateOf(BotDifficulty.MEDIUM) }
    var userName by remember { mutableStateOf(initialUserName) }
    var userColor by remember { mutableStateOf(PlayerColor.RED) }

    val scrollState = rememberScrollState()
    val allColors = listOf(PlayerColor.RED, PlayerColor.GREEN, PlayerColor.YELLOW, PlayerColor.BLUE)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBackground)
            .padding(horizontal = 20.dp)
            .testTag("bot_setup_screen"),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // App Bar
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(SurfacePanel)
                        .border(1.dp, BorderHairline, CircleShape)
                        .testTag("bot_setup_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "Play With Computer",
                        style = Typography.titleMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Offline AI Bots • Legal Moves Only",
                        style = Typography.labelSmall,
                        color = TextMuted
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
        }

        // Scrollable Options Content
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(scrollState)
        ) {
            // 1. Total Opponents / Bot Count
            Text(
                text = "Match Size",
                style = Typography.labelLarge,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfacePanel)
                    .border(1.dp, BorderHairline, RoundedCornerShape(8.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    Pair(2, "vs 1 Bot"),
                    Pair(3, "vs 2 Bots"),
                    Pair(4, "vs 3 Bots")
                ).forEach { (count, label) ->
                    val isSelected = totalPlayers == count
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) AccentPrimary else SurfacePanel)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = ripple(bounded = true),
                                onClick = { totalPlayers = count }
                            )
                            .testTag("bot_count_$count"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            style = Typography.labelLarge,
                            color = if (isSelected) SurfaceBackground else TextSecondary,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 2. Bot Difficulty Selection (Easy / Medium / Hard)
            Text(
                text = "Bot Intelligence",
                style = Typography.labelLarge,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                BotDifficulty.values().forEach { difficulty ->
                    val isSelected = selectedDifficulty == difficulty
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) SurfaceElevated else SurfacePanel)
                            .border(if (isSelected) 1.5.dp else 1.dp, if (isSelected) AccentPrimary else BorderHairline, RoundedCornerShape(8.dp))
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = ripple(bounded = true),
                                onClick = { selectedDifficulty = difficulty }
                            )
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .testTag("bot_difficulty_${difficulty.name}"),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.SmartToy,
                                contentDescription = null,
                                tint = if (isSelected) AccentPrimary else TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = difficulty.displayName,
                                    style = Typography.bodyLarge,
                                    color = TextPrimary,
                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                )
                                Text(
                                    text = difficulty.description,
                                    style = Typography.bodyMedium,
                                    color = TextMuted
                                )
                            }
                        }

                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = AccentPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 3. User Name & Color Configuration
            Text(
                text = "Your Profile",
                style = Typography.labelLarge,
                color = TextSecondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfacePanel)
                    .border(1.dp, BorderHairline, RoundedCornerShape(8.dp))
                    .padding(14.dp)
            ) {
                Text(
                    text = "Player Name",
                    style = Typography.labelSmall,
                    color = TextMuted
                )
                BasicTextField(
                    value = userName,
                    onValueChange = { userName = it },
                    textStyle = TextStyle(
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    ),
                    cursorBrush = SolidColor(AccentPrimary),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 2.dp)
                        .testTag("bot_user_name_input")
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Choose Your Pawn Color",
                    style = Typography.labelSmall,
                    color = TextSecondary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    allColors.forEach { color ->
                        val isChosen = userColor == color
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isChosen) SurfaceElevated else SurfacePanel)
                                .border(if (isChosen) 2.dp else 1.dp, if (isChosen) color.primaryColor else BorderHairline, RoundedCornerShape(8.dp))
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = ripple(bounded = true),
                                onClick = { userColor = color }
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(color.primaryColor)
                                        .border(1.dp, color.accentColor, CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = color.displayName,
                                    style = Typography.labelSmall,
                                    color = if (isChosen) TextPrimary else TextSecondary,
                                    fontWeight = if (isChosen) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Start Game Button
        Button(
            onClick = {
                val cleanUserName = userName.trim().ifEmpty { "Player 1" }
                val botNames = listOf("Titan", "Vortex", "Orion", "Nova", "Atlas")

                val configuredPlayers = mutableListOf<Player>()
                // Add Human player
                configuredPlayers.add(
                    Player(
                        id = 0,
                        name = cleanUserName,
                        color = userColor,
                        isBot = false
                    )
                )

                // Assign remaining unique colors to bots
                val remainingColors = allColors.filter { it != userColor }.toMutableList()
                for (b in 1 until totalPlayers) {
                    val botColor = remainingColors.removeAt(0)
                    val botName = "Bot " + botNames[(b - 1) % botNames.size]
                    configuredPlayers.add(
                        Player(
                            id = b,
                            name = botName,
                            color = botColor,
                            isBot = true,
                            botDifficulty = selectedDifficulty
                        )
                    )
                }

                onStartGame(configuredPlayers)
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = AccentPrimary,
                contentColor = SurfaceBackground
            ),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
                .height(52.dp)
                .testTag("start_bot_match_button")
        ) {
            Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Start Match",
                style = Typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
