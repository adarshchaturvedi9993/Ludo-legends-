package com.example.ludo.model

import androidx.compose.ui.graphics.Color

/**
 * Authentic Ludo player colors in standard clockwise order:
 * RED (Top-Left) -> GREEN (Top-Right) -> YELLOW (Bottom-Right) -> BLUE (Bottom-Left)
 */
enum class PlayerColor(
    val displayName: String,
    val primaryColor: Color,
    val surfaceColor: Color,
    val accentColor: Color,
    val darkShade: Color,
    val startIndex: Int,      // Perimeter index (0..51) where token enters board
    val homeEntryIndex: Int,  // Perimeter index where token turns into home stretch
    val yardRow: Float,       // Center row of yard in 15x15 grid
    val yardCol: Float        // Center col of yard in 15x15 grid
) {
    RED(
        displayName = "Red",
        primaryColor = Color(0xFFE53935),
        surfaceColor = Color(0xFFFDE8E8),
        accentColor = Color(0xFFFF7675),
        darkShade = Color(0xFFB71C1C),
        startIndex = 0,
        homeEntryIndex = 50,
        yardRow = 2.5f,
        yardCol = 2.5f
    ),
    GREEN(
        displayName = "Green",
        primaryColor = Color(0xFF159B55),
        surfaceColor = Color(0xFFE6F6ED),
        accentColor = Color(0xFF48CF82),
        darkShade = Color(0xFF0D6837),
        startIndex = 13,
        homeEntryIndex = 11,
        yardRow = 2.5f,
        yardCol = 11.5f
    ),
    YELLOW(
        displayName = "Yellow",
        primaryColor = Color(0xFFF5C928),
        surfaceColor = Color(0xFFFEF9E6),
        accentColor = Color(0xFFFDE68A),
        darkShade = Color(0xFFB78900),
        startIndex = 26,
        homeEntryIndex = 24,
        yardRow = 11.5f,
        yardCol = 11.5f
    ),
    BLUE(
        displayName = "Blue",
        primaryColor = Color(0xFF2878D0),
        surfaceColor = Color(0xFFE8F2FC),
        accentColor = Color(0xFF68A7EC),
        darkShade = Color(0xFF154E94),
        startIndex = 39,
        homeEntryIndex = 37,
        yardRow = 11.5f,
        yardCol = 2.5f
    );

    fun stepToTrackIndex(stepsTraveled: Int): Int {
        return (startIndex + stepsTraveled) % 52
    }
}
