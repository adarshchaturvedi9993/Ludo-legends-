package com.example.ludo.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ludo.model.PlayerColor
import com.example.ui.theme.StarGold
import kotlin.math.cos
import kotlin.math.sin

/**
 * Professional 2D/2.5D physical Ludo game-piece pawn:
 * - Proper proportioned body and base: flared foot, tapered waist, protruding collar, rounded head.
 * - Realistic directional highlights, specular glints, and subtle 3D shadows.
 * - Dark contour outline guaranteeing high contrast against any tile (especially its own home color).
 * - Dynamic contact shadow responding to hop elevation.
 * - Luminous selection indicator when movable.
 */
@Composable
fun TurnedPawn(
    color: PlayerColor,
    isMovable: Boolean,
    isFinished: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 34.dp,
    hopElevationPx: Float = 0f
) {
    Canvas(modifier = modifier.size(size)) {
        drawTurnedPawn(
            color = color,
            isMovable = isMovable,
            isFinished = isFinished,
            hopElevation = hopElevationPx
        )
    }
}

fun DrawScope.drawTurnedPawn(
    color: PlayerColor,
    isMovable: Boolean,
    isFinished: Boolean,
    hopElevation: Float = 0f
) {
    val w = size.width
    val h = size.height
    val cx = w * 0.5f

    // 1. Realistic contact shadow on tile surface (beneath flared foot)
    val shadowW = (w * 0.84f) * (1f - (hopElevation / 120f).coerceIn(0f, 0.45f))
    val shadowH = (h * 0.24f) * (1f - (hopElevation / 120f).coerceIn(0f, 0.45f))
    val shadowAlpha = (0.50f - (hopElevation / 140f).coerceIn(0f, 0.35f))
    drawOval(
        color = Color.Black.copy(alpha = shadowAlpha),
        topLeft = Offset(cx - shadowW / 2f, h * 0.76f + (hopElevation * 0.1f)),
        size = Size(shadowW, shadowH)
    )

    // Vertical hop elevation offset
    val lift = -hopElevation

    // 2. Movable luminous pulse ring around the base if enabled
    if (isMovable) {
        drawOval(
            color = StarGold,
            topLeft = Offset(cx - (w * 0.46f), h * 0.70f + lift),
            size = Size(w * 0.92f, h * 0.28f),
            style = Stroke(width = 2.dp.toPx())
        )
        drawOval(
            color = Color.White.copy(alpha = 0.85f),
            topLeft = Offset(cx - (w * 0.43f), h * 0.72f + lift),
            size = Size(w * 0.86f, h * 0.24f),
            style = Stroke(width = 1.dp.toPx())
        )
    }

    // 3. Flared Foot Base (Substantial disc with 3D bevel)
    val footBottomY = h * 0.93f + lift
    val footTopY = h * 0.71f + lift
    val footHalfW = w * 0.40f
    val footTopHalfW = w * 0.26f

    // Base body path
    val footPath = Path().apply {
        moveTo(cx - footHalfW, footBottomY)
        cubicTo(
            cx - footHalfW * 0.92f, footBottomY - h * 0.08f,
            cx - footTopHalfW * 1.08f, footTopY + h * 0.05f,
            cx - footTopHalfW, footTopY
        )
        lineTo(cx + footTopHalfW, footTopY)
        cubicTo(
            cx + footTopHalfW * 1.08f, footTopY + h * 0.05f,
            cx + footHalfW * 0.92f, footBottomY - h * 0.08f,
            cx + footHalfW, footBottomY
        )
        close()
    }

    val footGradient = Brush.horizontalGradient(
        colors = listOf(
            color.accentColor,
            color.primaryColor,
            color.darkShade
        ),
        startX = cx - footHalfW,
        endX = cx + footHalfW
    )
    drawPath(footPath, footGradient, style = Fill)
    // Dark outline for guaranteed contrast against matching colored tiles
    drawPath(footPath, color.darkShade.copy(alpha = 0.95f), style = Stroke(width = 1.2.dp.toPx()))

    // Flared Foot Bottom Rim Bevel
    drawOval(
        brush = Brush.horizontalGradient(
            colors = listOf(color.accentColor, color.primaryColor, color.darkShade),
            startX = cx - footHalfW,
            endX = cx + footHalfW
        ),
        topLeft = Offset(cx - footHalfW, footBottomY - h * 0.06f),
        size = Size(footHalfW * 2f, h * 0.12f)
    )
    drawOval(
        color = color.darkShade.copy(alpha = 0.9f),
        topLeft = Offset(cx - footHalfW, footBottomY - h * 0.06f),
        size = Size(footHalfW * 2f, h * 0.12f),
        style = Stroke(width = 1.dp.toPx())
    )

    // 4. Conical Body / Waist
    val waistBottomY = footTopY
    val waistTopY = h * 0.43f + lift
    val waistMidHalfW = w * 0.15f
    val waistTopHalfW = w * 0.18f

    val waistPath = Path().apply {
        moveTo(cx - footTopHalfW, waistBottomY)
        cubicTo(
            cx - waistMidHalfW, waistBottomY - h * 0.10f,
            cx - waistMidHalfW, waistTopY + h * 0.08f,
            cx - waistTopHalfW, waistTopY
        )
        lineTo(cx + waistTopHalfW, waistTopY)
        cubicTo(
            cx + waistMidHalfW, waistTopY + h * 0.08f,
            cx + waistMidHalfW, waistBottomY - h * 0.10f,
            cx + footTopHalfW, waistBottomY
        )
        close()
    }

    val waistGradient = Brush.horizontalGradient(
        colors = listOf(
            color.accentColor,
            color.primaryColor,
            color.darkShade
        ),
        startX = cx - footTopHalfW,
        endX = cx + footTopHalfW
    )
    drawPath(waistPath, waistGradient, style = Fill)
    drawPath(waistPath, color.darkShade.copy(alpha = 0.95f), style = Stroke(width = 1.dp.toPx()))

    // 5. Collar Ring (Protruding glossy torus ring below head)
    val collarY = h * 0.42f + lift
    val collarHalfW = w * 0.24f
    val collarHeight = h * 0.10f

    drawOval(
        brush = Brush.horizontalGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.8f),
                color.accentColor,
                color.primaryColor,
                color.darkShade
            ),
            startX = cx - collarHalfW,
            endX = cx + collarHalfW
        ),
        topLeft = Offset(cx - collarHalfW, collarY - collarHeight / 2f),
        size = Size(collarHalfW * 2f, collarHeight)
    )
    drawOval(
        color = color.darkShade.copy(alpha = 0.9f),
        topLeft = Offset(cx - collarHalfW, collarY - collarHeight / 2f),
        size = Size(collarHalfW * 2f, collarHeight),
        style = Stroke(width = 1.dp.toPx())
    )

    // Collar highlight glint
    drawOval(
        color = Color.White.copy(alpha = 0.85f),
        topLeft = Offset(cx - collarHalfW * 0.60f, collarY - collarHeight * 0.35f),
        size = Size(collarHalfW * 0.45f, collarHeight * 0.35f)
    )

    // 6. Lit Spherical Head
    val headRadius = w * 0.27f
    val headCenter = Offset(cx, h * 0.25f + lift)

    // Spherical gradient lighting
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.95f),
                color.accentColor,
                color.primaryColor,
                color.darkShade
            ),
            center = Offset(headCenter.x - headRadius * 0.32f, headCenter.y - headRadius * 0.35f),
            radius = headRadius * 1.30f
        ),
        radius = headRadius,
        center = headCenter
    )

    // Dark contour rim stroke around head for crisp contrast against any board background
    drawCircle(
        color = color.darkShade.copy(alpha = 0.95f),
        radius = headRadius,
        center = headCenter,
        style = Stroke(width = 1.2.dp.toPx())
    )

    // 7. Realistic Specular Glint (Top-left 315° light source)
    drawOval(
        color = Color.White.copy(alpha = 0.92f),
        topLeft = Offset(headCenter.x - headRadius * 0.60f, headCenter.y - headRadius * 0.68f),
        size = Size(headRadius * 0.52f, headRadius * 0.32f)
    )

    // Secondary subtle rim reflection on opposite bottom-right edge
    drawArc(
        color = Color.White.copy(alpha = 0.35f),
        startAngle = 30f,
        sweepAngle = 90f,
        useCenter = false,
        topLeft = Offset(headCenter.x - headRadius * 0.90f, headCenter.y - headRadius * 0.90f),
        size = Size(headRadius * 1.80f, headRadius * 1.80f),
        style = Stroke(width = 1.dp.toPx())
    )

    // 8. Finished Winner Badge
    if (isFinished) {
        drawCircle(
            color = StarGold,
            radius = headRadius * 0.40f,
            center = headCenter
        )
        // Little 5-point star on crown
        drawPawnMiniStar(headCenter.x, headCenter.y, headRadius * 0.30f, Color.White)
    }
}

private fun DrawScope.drawPawnMiniStar(cx: Float, cy: Float, radius: Float, color: Color) {
    val path = Path()
    val innerRadius = radius * 0.45f
    val numPoints = 5
    var angle = -Math.PI / 2.0

    for (i in 0 until numPoints * 2) {
        val r = if (i % 2 == 0) radius else innerRadius
        val x = (cx + cos(angle) * r).toFloat()
        val y = (cy + sin(angle) * r).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        angle += Math.PI / numPoints
    }
    path.close()
    drawPath(path, color, style = Fill)
}
