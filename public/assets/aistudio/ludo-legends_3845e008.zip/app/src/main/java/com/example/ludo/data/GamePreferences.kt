package com.example.ludo.data

import android.content.Context
import android.content.SharedPreferences
import com.example.ludo.model.GameState
import com.example.ludo.model.Player
import com.example.ludo.model.PlayerColor
import com.example.ludo.model.Token
import com.example.ludo.model.TokenState
import org.json.JSONArray
import org.json.JSONObject

class GamePreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ludo_game_prefs", Context.MODE_PRIVATE)

    var isSoundEnabled: Boolean
        get() = prefs.getBoolean(KEY_SOUND, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND, value).apply()

    var isMusicEnabled: Boolean
        get() = prefs.getBoolean(KEY_MUSIC, true)
        set(value) = prefs.edit().putBoolean(KEY_MUSIC, value).apply()

    var isHapticsEnabled: Boolean
        get() = prefs.getBoolean(KEY_HAPTICS, true)
        set(value) = prefs.edit().putBoolean(KEY_HAPTICS, value).apply()

    fun getPlayerName(slot: Int, default: String): String {
        return prefs.getString("player_name_$slot", default) ?: default
    }

    fun setPlayerName(slot: Int, name: String) {
        prefs.edit().putString("player_name_$slot", name).apply()
    }

    fun hasSavedGame(): Boolean {
        return prefs.contains(KEY_SAVED_GAME)
    }

    fun clearSavedGame() {
        prefs.edit().remove(KEY_SAVED_GAME).apply()
    }

    fun saveGame(state: GameState) {
        if (state.isGameOver) {
            clearSavedGame()
            return
        }
        try {
            val root = JSONObject()
            root.put("currentPlayerIndex", state.currentPlayerIndex)
            root.put("diceValue", state.diceValue)
            root.put("turnCount", state.turnCount)
            root.put("consecutiveSixes", state.consecutiveSixes)
            root.put("canRollAgain", state.canRollAgain)

            val playersArr = JSONArray()
            for (p in state.players) {
                val pObj = JSONObject()
                pObj.put("id", p.id)
                pObj.put("name", p.name)
                pObj.put("color", p.color.name)
                pObj.put("sixesCount", p.sixesCount)
                pObj.put("isBot", p.isBot)
                pObj.put("botDifficulty", p.botDifficulty.name)
                if (p.rank != null) pObj.put("rank", p.rank)

                val tokensArr = JSONArray()
                for (t in p.tokens) {
                    val tObj = JSONObject()
                    tObj.put("id", t.id)
                    tObj.put("state", t.state.name)
                    tObj.put("stepsTraveled", t.stepsTraveled)
                    tObj.put("homeStep", t.homeStep)
                    tokensArr.put(tObj)
                }
                pObj.put("tokens", tokensArr)
                playersArr.put(pObj)
            }
            root.put("players", playersArr)

            prefs.edit().putString(KEY_SAVED_GAME, root.toString()).apply()
        } catch (_: Exception) {
            // Ignore persistence errors
        }
    }

    fun loadSavedGame(): GameState? {
        val jsonStr = prefs.getString(KEY_SAVED_GAME, null) ?: return null
        return try {
            val root = JSONObject(jsonStr)
            val currentPlayerIndex = root.getInt("currentPlayerIndex")
            val diceValue = root.getInt("diceValue")
            val turnCount = root.optInt("turnCount", 1)
            val consecutiveSixes = root.optInt("consecutiveSixes", 0)
            val canRollAgain = root.optBoolean("canRollAgain", false)

            val playersArr = root.getJSONArray("players")
            val players = mutableListOf<Player>()
            for (i in 0 until playersArr.length()) {
                val pObj = playersArr.getJSONObject(i)
                val id = pObj.getInt("id")
                val name = pObj.getString("name")
                val color = PlayerColor.valueOf(pObj.getString("color"))
                val sixesCount = pObj.optInt("sixesCount", 0)
                val capturesCount = pObj.optInt("capturesCount", 0)
                val rank = if (pObj.has("rank")) pObj.getInt("rank") else null

                val tokensArr = pObj.getJSONArray("tokens")
                val tokens = mutableListOf<Token>()
                for (j in 0 until tokensArr.length()) {
                    val tObj = tokensArr.getJSONObject(j)
                    val tId = tObj.getInt("id")
                    val state = TokenState.valueOf(tObj.getString("state"))
                    val stepsTraveled = tObj.getInt("stepsTraveled")
                    val homeStep = tObj.getInt("homeStep")
                    tokens.add(
                        Token(
                            id = tId,
                            color = color,
                            state = state,
                            stepsTraveled = stepsTraveled,
                            homeStep = homeStep
                        )
                    )
                }
                val isBot = pObj.optBoolean("isBot", false)
                val botDiffStr = pObj.optString("botDifficulty", "MEDIUM")
                val botDifficulty = try { com.example.ludo.model.BotDifficulty.valueOf(botDiffStr) } catch (_: Exception) { com.example.ludo.model.BotDifficulty.MEDIUM }

                players.add(
                    Player(
                        id = id,
                        name = name,
                        color = color,
                        tokens = tokens,
                        rank = rank,
                        sixesCount = sixesCount,
                        capturesCount = capturesCount,
                        isBot = isBot,
                        botDifficulty = botDifficulty
                    )
                )
            }

            GameState(
                players = players,
                currentPlayerIndex = currentPlayerIndex,
                diceValue = diceValue,
                turnCount = turnCount,
                consecutiveSixes = consecutiveSixes,
                canRollAgain = canRollAgain,
                isWaitingForRoll = true,
                statusMessage = "${players[currentPlayerIndex].name}'s turn to roll"
            )
        } catch (_: Exception) {
            clearSavedGame()
            null
        }
    }

    companion object {
        private const val KEY_SOUND = "key_sound_enabled"
        private const val KEY_MUSIC = "key_music_enabled"
        private const val KEY_HAPTICS = "key_haptics_enabled"
        private const val KEY_SAVED_GAME = "key_saved_game_json"
    }
}
