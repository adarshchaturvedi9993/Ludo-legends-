package com.example.ludo.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.ludo.model.BoardCoordinates
import com.example.ludo.model.GridCoord
import com.example.ludo.model.Player
import com.example.ludo.model.PlayerColor
import com.example.ludo.model.TokenState
import com.example.ui.theme.CreamBoardSurface
import com.example.ui.theme.CreamTileBorder
import com.example.ui.theme.CreamTileSurface
import com.example.ui.theme.LudoBlue
import com.example.ui.theme.LudoBlueSurface
import com.example.ui.theme.LudoGreen
import com.example.ui.theme.LudoGreenSurface
import com.example.ui.theme.LudoRed
import com.example.ui.theme.LudoRedSurface
import com.example.ui.theme.LudoYellow
import com.example.ui.theme.LudoYellowSurface
import com.example.ui.theme.StarGold
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Professional commercial Ludo Board component:
 * - Exact traditional colors: Red #E53935, Green #159B55, Yellow #F5C928, Blue #2878D0.
 * - Board background: #FFFDF5, Grid lines: #D8D5C8, Safe zones & stars: #E5B93B.
 * - Perfectly square aspect ratio, consistent grid lines, rounded outer corners.
 * - Each player home area has its own identifiable color with subtle tinted background and 4 visible starting pedestals.
 * - Red, Green, Yellow, Blue home paths filled with solid vibrant player colors.
 * - Center home area contains 4 accurately aligned colored triangles meeting at the center.
 * - Safe stars clearly visible on all 8 safe cells.
 * - Large, crisp, professional 2.5D pawns with hop-by-hop animation.
 */
@Composable
fun LudoBoardView(
    players: List<Player>,
    currentPlayer: Player,
    movableTokenIds: Set<Int>,
    onTokenClick: (Int) -> Unit,
    modifier: Modifier = Modifier,
    animatingTokenId: Int? = null,
    animatingTokenCoord: GridCoord? = null,
    animatingHopElevationPx: Float = 0f
) {
    BoxWithConstraints(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(12.dp))
            .background(CreamBoardSurface)
            .border(2.dp, CreamTileBorder, RoundedCornerShape(12.dp))
            .testTag("ludo_board_view")
    ) {
        val boardSizePx = constraints.maxWidth.toFloat()
        val cellSizePx = boardSizePx / BoardCoordinates.GRID_SIZE

        // 1. Draw static Board geometry with traditional colors and markings
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawTraditionalLudoBoard(cellSizePx)
        }

        // 2. Render authentic 2.5D turned pawns on top
        val allTokens = players.flatMap { it.tokens }
        val tokensByCoord = allTokens.groupBy { token ->
            val coord = if (token.id == animatingTokenId && animatingTokenCoord != null) {
                animatingTokenCoord
            } else {
                BoardCoordinates.getCoordinate(token)
            }
            Pair((coord.row * 10).roundToInt(), (coord.col * 10).roundToInt())
        }

        val infiniteTransition = rememberInfiniteTransition(label = "pulse")
        val pulseScale = infiniteTransition.animateFloat(
            initialValue = 1.0f,
            targetValue = 1.16f,
            animationSpec = infiniteRepeatable(
                animation = tween(600, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "tokenPulse"
        )

        val density = LocalDensity.current

        for (player in players) {
            val isCurrentPlayer = player.id == currentPlayer.id
            for (token in player.tokens) {
                val isAnimatingThisToken = token.id == animatingTokenId && player.id == currentPlayer.id
                val coord = if (isAnimatingThisToken && animatingTokenCoord != null) {
                    animatingTokenCoord
                } else {
                    BoardCoordinates.getCoordinate(token)
                }

                val key = Pair((coord.row * 10).roundToInt(), (coord.col * 10).roundToInt())
                val cluster = tokensByCoord[key] ?: listOf(token)
                val indexInCluster = cluster.indexOf(token)
                val clusterSize = cluster.size

                val isMovable = isCurrentPlayer && movableTokenIds.contains(token.id)

                // Cluster offset when multiple tokens occupy the same tile
                val (offsetX, offsetY) = if (clusterSize > 1 && token.state != TokenState.YARD && !isAnimatingThisToken) {
                    val angle = (2.0 * Math.PI * indexInCluster / clusterSize).toFloat()
                    val radius = cellSizePx * 0.22f
                    Pair(cos(angle) * radius, sin(angle) * radius)
                } else {
                    Pair(0f, 0f)
                }

                val centerX = (coord.col + 0.5f) * cellSizePx + offsetX
                val centerY = (coord.row + 0.5f) * cellSizePx + offsetY

                // Substantial pawn size for clear visibility and comfortable tapping
                val pawnSizePx = if (token.state == TokenState.YARD) cellSizePx * 0.94f else cellSizePx * 0.92f
                val pawnSizeDp = with(density) { pawnSizePx.toDp() }

                val hopElevation = if (isAnimatingThisToken) animatingHopElevationPx else 0f

                Box(
                    modifier = Modifier
                        .offset {
                            IntOffset(
                                x = (centerX - pawnSizePx / 2f).roundToInt(),
                                y = (centerY - pawnSizePx / 2f).roundToInt()
                            )
                        }
                        .size(pawnSizeDp)
                        .scale(if (isMovable) pulseScale.value else 1.0f)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(bounded = true, radius = pawnSizeDp / 2),
                            enabled = isMovable,
                            onClick = { onTokenClick(token.id) }
                        )
                        .testTag("pawn_${player.color.name}_${token.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    TurnedPawn(
                        color = player.color,
                        isMovable = isMovable,
                        isFinished = token.isFinished,
                        size = pawnSizeDp,
                        hopElevationPx = hopElevation
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawTraditionalLudoBoard(cell: Float) {
    val hairline = 1.dp.toPx()
    val gridBorderColor = CreamTileBorder

    // 1. Draw Corner Yards (6x6 cells each)
    // Top-Left: Red
    drawTraditionalYard(
        left = 0f,
        top = 0f,
        size = cell * 6,
        cell = cell,
        playerColor = LudoRed,
        surfaceColor = LudoRedSurface,
        slots = BoardCoordinates.RED_YARD_SLOTS
    )
    // Top-Right: Green
    drawTraditionalYard(
        left = cell * 9,
        top = 0f,
        size = cell * 6,
        cell = cell,
        playerColor = LudoGreen,
        surfaceColor = LudoGreenSurface,
        slots = BoardCoordinates.GREEN_YARD_SLOTS
    )
    // Bottom-Right: Yellow
    drawTraditionalYard(
        left = cell * 9,
        top = cell * 9,
        size = cell * 6,
        cell = cell,
        playerColor = LudoYellow,
        surfaceColor = LudoYellowSurface,
        slots = BoardCoordinates.YELLOW_YARD_SLOTS
    )
    // Bottom-Left: Blue
    drawTraditionalYard(
        left = 0f,
        top = cell * 9,
        size = cell * 6,
        cell = cell,
        playerColor = LudoBlue,
        surfaceColor = LudoBlueSurface,
        slots = BoardCoordinates.BLUE_YARD_SLOTS
    )

    // 2. Draw 52 Perimeter Track cells with clean cream surface and grid lines
    val trackIndices = BoardCoordinates.TRACK_TILES
    for (i in trackIndices.indices) {
        val coord = trackIndices[i]
        val x = coord.col * cell
        val y = coord.row * cell

        // Default cream tile background
        drawRect(
            color = CreamTileSurface,
            topLeft = Offset(x, y),
            size = Size(cell, cell)
        )
        // Consistent grid hairline border
        drawRect(
            color = gridBorderColor,
            topLeft = Offset(x, y),
            size = Size(cell, cell),
            style = Stroke(width = hairline)
        )
    }

    // 3. Draw Starting Cells (Solid player color with gold safe star)
    fun drawStartCell(index: Int, color: Color) {
        val coord = trackIndices[index]
        val x = coord.col * cell
        val y = coord.row * cell
        // Solid player color
        drawRect(
            color = color,
            topLeft = Offset(x, y),
            size = Size(cell, cell)
        )
        // Grid border
        drawRect(
            color = gridBorderColor,
            topLeft = Offset(x, y),
            size = Size(cell, cell),
            style = Stroke(width = hairline)
        )
        // Safe star on starting cell
        drawBoardStar(
            centerX = (coord.col + 0.5f) * cell,
            centerY = (coord.row + 0.5f) * cell,
            radius = cell * 0.34f,
            color = Color.White
        )
    }

    drawStartCell(0, LudoRed)
    drawStartCell(13, LudoGreen)
    drawStartCell(26, LudoYellow)
    drawStartCell(39, LudoBlue)

    // 4. Draw Safe Stars on the 4 track safe tiles (Indices: 8, 21, 34, 47)
    val trackSafeIndices = listOf(8, 21, 34, 47)
    for (safeIdx in trackSafeIndices) {
        val coord = trackIndices[safeIdx]
        drawBoardStar(
            centerX = (coord.col + 0.5f) * cell,
            centerY = (coord.row + 0.5f) * cell,
            radius = cell * 0.34f,
            color = StarGold
        )
    }

    // 5. Draw Solid Colored Home Run Corridors (5 cells each)
    fun drawHomeLane(coords: List<GridCoord>, color: Color) {
        for (coord in coords) {
            val x = coord.col * cell
            val y = coord.row * cell
            drawRect(
                color = color,
                topLeft = Offset(x, y),
                size = Size(cell, cell)
            )
            drawRect(
                color = gridBorderColor,
                topLeft = Offset(x, y),
                size = Size(cell, cell),
                style = Stroke(width = hairline)
            )
        }
    }

    drawHomeLane(BoardCoordinates.RED_HOME, LudoRed)
    drawHomeLane(BoardCoordinates.GREEN_HOME, LudoGreen)
    drawHomeLane(BoardCoordinates.YELLOW_HOME, LudoYellow)
    drawHomeLane(BoardCoordinates.BLUE_HOME, LudoBlue)

    // 6. Draw Central Home Area with 4 Accurately Aligned Coloured Triangles
    val cx = 7.5f * cell
    val cy = 7.5f * cell
    val goalLeft = 6f * cell
    val goalRight = 9f * cell
    val goalTop = 6f * cell
    val goalBottom = 9f * cell

    // Center base surface
    drawRect(
        color = CreamBoardSurface,
        topLeft = Offset(goalLeft, goalTop),
        size = Size(cell * 3, cell * 3)
    )

    // Red Triangle (Left)
    val redPath = Path().apply {
        moveTo(goalLeft, goalTop)
        lineTo(cx, cy)
        lineTo(goalLeft, goalBottom)
        close()
    }
    drawPath(redPath, LudoRed, style = Fill)

    // Green Triangle (Top)
    val greenPath = Path().apply {
        moveTo(goalLeft, goalTop)
        lineTo(goalRight, goalTop)
        lineTo(cx, cy)
        close()
    }
    drawPath(greenPath, LudoGreen, style = Fill)

    // Yellow Triangle (Right)
    val yellowPath = Path().apply {
        moveTo(goalRight, goalTop)
        lineTo(goalRight, goalBottom)
        lineTo(cx, cy)
        close()
    }
    drawPath(yellowPath, LudoYellow, style = Fill)

    // Blue Triangle (Bottom)
    val bluePath = Path().apply {
        moveTo(goalLeft, goalBottom)
        lineTo(cx, cy)
        lineTo(goalRight, goalBottom)
        close()
    }
    drawPath(bluePath, LudoBlue, style = Fill)

    // Clean boundary and diagonal grid lines through center
    val centerStroke = 1.5.dp.toPx()
    drawLine(gridBorderColor, Offset(goalLeft, goalTop), Offset(goalRight, goalBottom), strokeWidth = centerStroke)
    drawLine(gridBorderColor, Offset(goalLeft, goalBottom), Offset(goalRight, goalTop), strokeWidth = centerStroke)

    // Center box outline
    drawRect(
        color = gridBorderColor,
        topLeft = Offset(goalLeft, goalTop),
        size = Size(cell * 3, cell * 3),
        style = Stroke(width = centerStroke)
    )
}

/**
 * Renders an authentic Ludo home yard:
 * - Solid colored frame in player's traditional color.
 * - Subtle color-tinted inner background.
 * - Crisp white rounded card in center.
 * - 4 distinct circular starting pedestals matching token initial positions.
 */
private fun DrawScope.drawTraditionalYard(
    left: Float,
    top: Float,
    size: Float,
    cell: Float,
    playerColor: Color,
    surfaceColor: Color,
    slots: List<GridCoord>
) {
    val hairline = 1.5.dp.toPx()

    // 1. Yard outer background with player's color tint
    drawRoundRect(
        color = surfaceColor,
        topLeft = Offset(left, top),
        size = Size(size, size),
        cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
    )

    // Yard solid colored outer boundary
    drawRoundRect(
        color = playerColor,
        topLeft = Offset(left, top),
        size = Size(size, size),
        cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx()),
        style = Stroke(width = 2.5.dp.toPx())
    )

    // 2. Center white card
    val innerMargin = cell * 0.9f
    val innerSize = size - (innerMargin * 2)
    drawRoundRect(
        color = CreamBoardSurface,
        topLeft = Offset(left + innerMargin, top + innerMargin),
        size = Size(innerSize, innerSize),
        cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx())
    )
    drawRoundRect(
        color = playerColor.copy(alpha = 0.5f),
        topLeft = Offset(left + innerMargin, top + innerMargin),
        size = Size(innerSize, innerSize),
        cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx()),
        style = Stroke(width = hairline)
    )

    // 3. Four circular starting pedestals located at token slots
    for (slot in slots) {
        val pedestalCx = (slot.col + 0.5f) * cell
        val pedestalCy = (slot.row + 0.5f) * cell

        // Outer ring in player color
        drawCircle(
            color = playerColor,
            radius = cell * 0.44f,
            center = Offset(pedestalCx, pedestalCy)
        )
        // Inner white disc
        drawCircle(
            color = CreamBoardSurface,
            radius = cell * 0.38f,
            center = Offset(pedestalCx, pedestalCy)
        )
        // Concentric center target ring
        drawCircle(
            color = playerColor.copy(alpha = 0.4f),
            radius = cell * 0.22f,
            center = Offset(pedestalCx, pedestalCy),
            style = Stroke(width = 1.dp.toPx())
        )
    }
}

/**
 * Draws a sharp 5-pointed star.
 */
private fun DrawScope.drawBoardStar(
    centerX: Float,
    centerY: Float,
    radius: Float,
    color: Color
) {
    val path = Path()
    val innerRadius = radius * 0.40f
    val numPoints = 5
    var angle = -Math.PI / 2.0

    for (i in 0 until numPoints * 2) {
        val r = if (i % 2 == 0) radius else innerRadius
        val x = (centerX + cos(angle) * r).toFloat()
        val y = (centerY + sin(angle) * r).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        angle += Math.PI / numPoints
    }
    path.close()
    drawPath(path, color, style = Fill)
    // Subtle dark hairline border around star for crisp contrast
    drawPath(path, Color.Black.copy(alpha = 0.25f), style = Stroke(width = 0.75.dp.toPx()))
}
