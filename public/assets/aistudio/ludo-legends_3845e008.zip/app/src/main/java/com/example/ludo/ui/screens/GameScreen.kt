package com.example.ludo.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MusicNote
import androidx.compose.material.icons.outlined.MusicOff
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ludo.ai.LudoBotAI
import com.example.ludo.audio.SoundManager
import com.example.ludo.engine.LudoGameEngine
import com.example.ludo.engine.MoveOutcome
import com.example.ludo.model.BoardCoordinates
import com.example.ludo.model.GameState
import com.example.ludo.model.GridCoord
import com.example.ludo.ui.components.LudoBoardView
import com.example.ludo.ui.components.PlayerBar
import com.example.ludo.ui.components.Realistic3DDiceView
import com.example.ui.theme.AccentPrimary
import com.example.ui.theme.BorderHairline
import com.example.ui.theme.StarGold
import com.example.ui.theme.SurfaceBackground
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.SurfacePanel
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.Typography
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun GameScreen(
    gameState: GameState,
    soundManager: SoundManager,
    onStateUpdated: (GameState) -> Unit,
    onGameFinished: (GameState) -> Unit,
    onExitToMenu: () -> Unit,
    onRestartGame: () -> Unit
) {
    var showPauseDialog by remember { mutableStateOf(false) }
    var isSoundMuted by remember { mutableStateOf(!soundManager.isSoundEnabled) }
    var isMusicOn by remember { mutableStateOf(soundManager.isMusicEnabled) }
    val coroutineScope = rememberCoroutineScope()
    val currentPlayer = gameState.currentPlayer

    // Hop-by-hop animation tracking states
    var animatingTokenId by remember { mutableStateOf<Int?>(null) }
    var animatingTokenCoord by remember { mutableStateOf<GridCoord?>(null) }
    var animatingHopElevationPx by remember { mutableFloatStateOf(0f) }
    var isHopAnimating by remember { mutableStateOf(false) }

    // Handle game over condition
    LaunchedEffect(gameState.isGameOver) {
        if (gameState.isGameOver) {
            soundManager.playVictory()
            delay(600)
            onGameFinished(gameState)
        }
    }

    // Auto-advance turn if no moves available
    LaunchedEffect(gameState.isWaitingForRoll, gameState.movableTokenIds, gameState.isDiceRolling, isHopAnimating) {
        if (!gameState.isWaitingForRoll && !gameState.isDiceRolling && gameState.movableTokenIds.isEmpty() && !isHopAnimating) {
            delay(1000)
            val nextIndex = LudoGameEngine.getNextActivePlayerIndex(gameState.players, gameState.currentPlayerIndex)
            val nextState = gameState.copy(
                currentPlayerIndex = nextIndex,
                isWaitingForRoll = true,
                movableTokenIds = emptySet(),
                statusMessage = "${gameState.players[nextIndex].name}'s turn to roll",
                turnCount = gameState.turnCount + 1
            )
            onStateUpdated(nextState)
        }
    }

    // Single legal move auto-execution for human players
    LaunchedEffect(gameState.isWaitingForRoll, gameState.movableTokenIds, gameState.isDiceRolling, isHopAnimating, currentPlayer.isBot) {
        if (!currentPlayer.isBot && !gameState.isWaitingForRoll && !gameState.isDiceRolling &&
            gameState.movableTokenIds.size == 1 && !isHopAnimating
        ) {
            val singleTokenId = gameState.movableTokenIds.first()
            delay(350)
            startHopAndMove(
                tokenId = singleTokenId,
                currentState = gameState,
                soundManager = soundManager,
                coroutineScope = coroutineScope,
                onStateUpdated = onStateUpdated,
                setAnimatingToken = { id, coord, elev ->
                    animatingTokenId = id
                    animatingTokenCoord = coord
                    animatingHopElevationPx = elev
                },
                setHopAnimating = { isHopAnimating = it }
            )
        }
    }

    // Coordinate automated Bot turns (Play With Computer)
    LaunchedEffect(currentPlayer.isBot, gameState.isWaitingForRoll, gameState.isDiceRolling, isHopAnimating, gameState.isGameOver) {
        if (currentPlayer.isBot && !gameState.isGameOver && !isHopAnimating) {
            if (gameState.isWaitingForRoll && !gameState.isDiceRolling) {
                // Realistic bot think time before rolling
                delay(450)
                handleRoll(
                    currentState = gameState,
                    soundManager = soundManager,
                    coroutineScope = coroutineScope,
                    onStateUpdated = onStateUpdated
                )
            } else if (!gameState.isWaitingForRoll && !gameState.isDiceRolling && gameState.movableTokenIds.isNotEmpty()) {
                // Realistic bot tactical decision time before moving
                delay(420)
                val chosenTokenId = LudoBotAI.chooseMove(currentPlayer, gameState, gameState.movableTokenIds)
                startHopAndMove(
                    tokenId = chosenTokenId,
                    currentState = gameState,
                    soundManager = soundManager,
                    coroutineScope = coroutineScope,
                    onStateUpdated = onStateUpdated,
                    setAnimatingToken = { id, coord, elev ->
                        animatingTokenId = id
                        animatingTokenCoord = coord
                        animatingHopElevationPx = elev
                    },
                    setHopAnimating = { isHopAnimating = it }
                )
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(SurfaceBackground)
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("game_screen")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Top Header: Compact pause button, Turn indicator, Sound toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Compact Pause Menu Button
                IconButton(
                    onClick = {
                        soundManager.playButtonTap()
                        showPauseDialog = true
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(SurfacePanel)
                        .border(1.dp, BorderHairline, CircleShape)
                        .testTag("pause_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Pause,
                        contentDescription = "Pause",
                        tint = TextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Clearly visible current turn indicator
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(SurfacePanel)
                        .border(1.dp, currentPlayer.color.primaryColor.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(currentPlayer.color.primaryColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Turn ${gameState.turnCount} • ${currentPlayer.name}",
                        style = Typography.labelMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (currentPlayer.isBot) {
                        Spacer(modifier = Modifier.width(5.dp))
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = "AI",
                            tint = StarGold,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }

                // Sound Toggle
                IconButton(
                    onClick = {
                        isSoundMuted = !isSoundMuted
                        soundManager.isSoundEnabled = !isSoundMuted
                        soundManager.playButtonTap()
                    },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(SurfacePanel)
                        .border(1.dp, BorderHairline, CircleShape)
                        .testTag("sound_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isSoundMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "Toggle Sound",
                        tint = if (isSoundMuted) TextMuted else TextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // 2. Player Information Cards
            PlayerBar(
                players = gameState.players,
                currentPlayer = currentPlayer,
                modifier = Modifier.padding(vertical = 2.dp)
            )

            // 3. Central Ludo Board (Main visual focus, perfectly square)
            LudoBoardView(
                players = gameState.players,
                currentPlayer = currentPlayer,
                movableTokenIds = if (isHopAnimating || currentPlayer.isBot) emptySet() else gameState.movableTokenIds,
                onTokenClick = { tokenId ->
                    if (!isHopAnimating && !currentPlayer.isBot) {
                        startHopAndMove(
                            tokenId = tokenId,
                            currentState = gameState,
                            soundManager = soundManager,
                            coroutineScope = coroutineScope,
                            onStateUpdated = onStateUpdated,
                            setAnimatingToken = { id, coord, elev ->
                                animatingTokenId = id
                                animatingTokenCoord = coord
                                animatingHopElevationPx = elev
                            },
                            setHopAnimating = { isHopAnimating = it }
                        )
                    }
                },
                animatingTokenId = animatingTokenId,
                animatingTokenCoord = animatingTokenCoord,
                animatingHopElevationPx = animatingHopElevationPx,
                modifier = Modifier.weight(1f, fill = false)
            )

            // 4. Polished Turn Information Status Component
            val turnStatusText = when {
                gameState.isGameOver -> "${gameState.winner?.name ?: currentPlayer.name} won!"
                gameState.isDiceRolling -> "Rolling the dice..."
                isHopAnimating -> "Advancing pawn..."
                gameState.isWaitingForRoll && currentPlayer.isBot -> "${currentPlayer.name} (AI) is rolling..."
                gameState.isWaitingForRoll -> "${currentPlayer.name}'s turn • Roll the dice!"
                gameState.diceValue == 6 && gameState.movableTokenIds.isNotEmpty() -> "You rolled a 6! Choose a pawn to move"
                gameState.movableTokenIds.isNotEmpty() -> "Choose a pawn to move"
                else -> "No moves available (Rolled ${gameState.diceValue})"
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(SurfacePanel)
                    .border(1.dp, if (gameState.diceValue == 6 && !gameState.isWaitingForRoll) StarGold else BorderHairline, RoundedCornerShape(8.dp))
                    .padding(vertical = 8.dp, horizontal = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (gameState.isWaitingForRoll) currentPlayer.color.primaryColor else StarGold)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = turnStatusText,
                        style = Typography.bodyMedium,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // 5. Bottom Player Panel with Large Interactive 3D Dice
            val isDiceInteractive = gameState.isWaitingForRoll && !gameState.isDiceRolling && !currentPlayer.isBot && !isHopAnimating
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfacePanel)
                    .border(
                        width = if (isDiceInteractive) 1.5.dp else 1.dp,
                        color = if (isDiceInteractive) currentPlayer.color.primaryColor.copy(alpha = 0.8f) else BorderHairline,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable(enabled = isDiceInteractive) {
                        handleRoll(
                            currentState = gameState,
                            soundManager = soundManager,
                            coroutineScope = coroutineScope,
                            onStateUpdated = onStateUpdated
                        )
                    }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left: Player info & turn instruction
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(CircleShape)
                                .background(currentPlayer.color.primaryColor)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = currentPlayer.name,
                            style = Typography.titleMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                        if (currentPlayer.isBot) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "(${currentPlayer.botDifficulty.displayName} AI)",
                                style = Typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    val bottomInstruction = when {
                        gameState.isDiceRolling -> "Rolling..."
                        isHopAnimating -> "Moving pawn..."
                        currentPlayer.isBot -> "AI thinking..."
                        gameState.isWaitingForRoll -> "Tap dice to roll!"
                        gameState.movableTokenIds.isNotEmpty() -> "Choose a pawn to move"
                        else -> "Turn passes to next player"
                    }
                    Text(
                        text = bottomInstruction,
                        style = Typography.labelMedium,
                        color = if (isDiceInteractive) AccentPrimary else TextSecondary,
                        fontWeight = if (isDiceInteractive) FontWeight.Medium else FontWeight.Normal
                    )
                }

                // Right: Large Interactive 3D Dice
                Realistic3DDiceView(
                    value = gameState.diceValue,
                    isRolling = gameState.isDiceRolling,
                    enabled = isDiceInteractive,
                    size = 68.dp,
                    accentColor = currentPlayer.color.primaryColor,
                    onBounce = {
                        soundManager.playDiceRoll()
                    },
                    onRollClick = {
                        handleRoll(
                            currentState = gameState,
                            soundManager = soundManager,
                            coroutineScope = coroutineScope,
                            onStateUpdated = onStateUpdated
                        )
                    }
                )
            }

            Spacer(modifier = Modifier.height(2.dp))
        }

        // Pause Menu Dialog
        if (showPauseDialog) {
            Dialog(onDismissRequest = { showPauseDialog = false }) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfacePanel)
                        .border(1.dp, BorderHairline, RoundedCornerShape(12.dp))
                        .padding(24.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Game Paused",
                            style = Typography.headlineSmall,
                            color = TextPrimary
                        )

                        Text(
                            text = "Match is saved automatically.",
                            style = Typography.bodyMedium,
                            color = TextMuted
                        )

                        // Audio Quick Toggles
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(SurfaceElevated)
                                    .border(1.dp, BorderHairline, RoundedCornerShape(6.dp))
                                    .clickable {
                                        isSoundMuted = !isSoundMuted
                                        soundManager.isSoundEnabled = !isSoundMuted
                                        soundManager.playButtonTap()
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isSoundMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                        contentDescription = null,
                                        tint = if (isSoundMuted) TextMuted else TextPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isSoundMuted) "SFX Off" else "SFX On",
                                        style = Typography.labelSmall,
                                        color = TextPrimary
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(40.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(SurfaceElevated)
                                    .border(1.dp, BorderHairline, RoundedCornerShape(6.dp))
                                    .clickable {
                                        isMusicOn = !isMusicOn
                                        soundManager.isMusicEnabled = isMusicOn
                                        soundManager.playButtonTap()
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isMusicOn) Icons.Outlined.MusicNote else Icons.Outlined.MusicOff,
                                        contentDescription = null,
                                        tint = if (isMusicOn) TextPrimary else TextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isMusicOn) "Music On" else "Music Off",
                                        style = Typography.labelSmall,
                                        color = TextPrimary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Resume button
                        Button(
                            onClick = {
                                soundManager.playButtonTap()
                                showPauseDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AccentPrimary,
                                contentColor = SurfaceBackground
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Resume", style = Typography.labelLarge)
                        }

                        // Restart button
                        OutlinedButton(
                            onClick = {
                                soundManager.playButtonTap()
                                showPauseDialog = false
                                onRestartGame()
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = androidx.compose.ui.graphics.SolidColor(BorderHairline)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(Icons.Outlined.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Restart Match", style = Typography.labelLarge)
                        }

                        // Exit to Main Menu
                        OutlinedButton(
                            onClick = {
                                soundManager.playButtonTap()
                                showPauseDialog = false
                                onExitToMenu()
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                            border = ButtonDefaults.outlinedButtonBorder.copy(
                                brush = androidx.compose.ui.graphics.SolidColor(BorderHairline)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(Icons.Outlined.Home, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Main Menu", style = Typography.labelLarge)
                        }
                    }
                }
            }
        }
    }
}

private fun handleRoll(
    currentState: GameState,
    soundManager: SoundManager,
    coroutineScope: CoroutineScope,
    onStateUpdated: (GameState) -> Unit
) {
    if (!currentState.isWaitingForRoll || currentState.isDiceRolling) return

    val rolledValue = Random.nextInt(1, 7)
    val currPlayer = currentState.currentPlayer
    val consecutiveSixes = if (rolledValue == 6) currentState.consecutiveSixes + 1 else 0

    // Roll animation start
    soundManager.playDiceRoll()
    val rollingState = currentState.copy(
        isDiceRolling = true,
        isWaitingForRoll = false,
        diceValue = rolledValue
    )
    onStateUpdated(rollingState)

    // After roll completes (520ms matching 3D tumble-and-bounce physics)
    coroutineScope.launch {
        delay(540)

        // 3 consecutive sixes anti-monopoly penalty
        if (consecutiveSixes >= 3) {
            val nextIndex = LudoGameEngine.getNextActivePlayerIndex(currentState.players, currentState.currentPlayerIndex)
            val penaltyState = currentState.copy(
                isDiceRolling = false,
                isWaitingForRoll = true,
                diceValue = rolledValue,
                consecutiveSixes = 0,
                currentPlayerIndex = nextIndex,
                statusMessage = "${currPlayer.name} rolled 3 sixes! Turn passed.",
                turnCount = currentState.turnCount + 1
            )
            onStateUpdated(penaltyState)
            return@launch
        }

        val movableIds = LudoGameEngine.getMovableTokenIds(currPlayer, rolledValue)
        val updatedSixes = if (rolledValue == 6) currPlayer.sixesCount + 1 else currPlayer.sixesCount
        val updatedPlayer = currPlayer.copy(sixesCount = updatedSixes)
        val allPlayers = currentState.players.toMutableList()
        val currIdx = allPlayers.indexOfFirst { it.id == currPlayer.id }
        allPlayers[currIdx] = updatedPlayer

        val status = when {
            movableIds.isEmpty() -> "${currPlayer.name} rolled $rolledValue. No valid moves."
            rolledValue == 6 -> "${currPlayer.name} rolled 6! Extra turn!"
            else -> "${currPlayer.name} rolled $rolledValue. Select a pawn."
        }

        val postRollState = currentState.copy(
            players = allPlayers,
            isDiceRolling = false,
            isWaitingForRoll = false,
            diceValue = rolledValue,
            movableTokenIds = movableIds,
            consecutiveSixes = consecutiveSixes,
            statusMessage = status
        )
        onStateUpdated(postRollState)
    }
}

/**
 * Animates a pawn hop-by-hop along its path with vertical elevation arcs and synchronized step taps.
 */
private fun startHopAndMove(
    tokenId: Int,
    currentState: GameState,
    soundManager: SoundManager,
    coroutineScope: CoroutineScope,
    onStateUpdated: (GameState) -> Unit,
    setAnimatingToken: (Int?, GridCoord?, Float) -> Unit,
    setHopAnimating: (Boolean) -> Unit
) {
    val currPlayer = currentState.currentPlayer
    val token = currPlayer.tokens.firstOrNull { it.id == tokenId } ?: return

    val hopPath = BoardCoordinates.computeHopPath(token, currentState.diceValue)
    if (hopPath.size <= 1) {
        // Direct move if no intermediate path
        val (nextState, outcome) = LudoGameEngine.executeMove(currentState, tokenId)
        when (outcome) {
            is MoveOutcome.Moved -> {
                if (outcome.capturedPlayerColor != null) soundManager.playCapture()
                else if (outcome.tokenFinished) soundManager.playTokenHome()
            }
            else -> {}
        }
        onStateUpdated(nextState)
        return
    }

    setHopAnimating(true)

    coroutineScope.launch {
        // Hop step-by-step
        for (i in 1 until hopPath.size) {
            val startCoord = hopPath[i - 1]
            val endCoord = hopPath[i]

            val frames = 8
            val frameDelay = 18L
            for (f in 1..frames) {
                val t = f.toFloat() / frames
                val curRow = startCoord.row + (endCoord.row - startCoord.row) * t
                val curCol = startCoord.col + (endCoord.col - startCoord.col) * t
                val elevation = 22f * sin(PI.toFloat() * t)

                setAnimatingToken(tokenId, GridCoord(curRow, curCol), elevation)
                delay(frameDelay)
            }

            // Clack sound on landing each hop
            soundManager.playTokenStep()
        }

        // Clear animation
        setAnimatingToken(null, null, 0f)
        setHopAnimating(false)

        // Finalize engine state
        val (nextState, outcome) = LudoGameEngine.executeMove(currentState, tokenId)
        when (outcome) {
            is MoveOutcome.Moved -> {
                if (outcome.capturedPlayerColor != null) {
                    soundManager.playCapture()
                } else if (outcome.tokenFinished) {
                    soundManager.playTokenHome()
                }
            }
            else -> {}
        }
        onStateUpdated(nextState)
    }
}
