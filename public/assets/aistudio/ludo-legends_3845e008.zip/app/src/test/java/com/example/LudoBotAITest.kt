package com.example

import com.example.ludo.ai.LudoBotAI
import com.example.ludo.model.BoardCoordinates
import com.example.ludo.model.BotDifficulty
import com.example.ludo.model.GameState
import com.example.ludo.model.Player
import com.example.ludo.model.PlayerColor
import com.example.ludo.model.Token
import com.example.ludo.model.TokenState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class LudoBotAITest {

    @Test
    fun testBotAlwaysPlaysLegalMove() {
        val botPlayer = Player(
            id = 1,
            name = "Bot Titan",
            color = PlayerColor.GREEN,
            isBot = true,
            botDifficulty = BotDifficulty.HARD
        )
        val humanPlayer = Player(id = 0, name = "Human", color = PlayerColor.RED)

        val legalIds = setOf(1, 3)
        val state = GameState(
            players = listOf(humanPlayer, botPlayer),
            currentPlayerIndex = 1,
            diceValue = 6,
            isWaitingForRoll = false,
            movableTokenIds = legalIds
        )

        // Run for all three difficulties multiple times
        for (difficulty in BotDifficulty.values()) {
            val playerWithDiff = botPlayer.copy(botDifficulty = difficulty)
            for (i in 0 until 10) {
                val chosen = LudoBotAI.chooseMove(playerWithDiff, state, legalIds)
                assertTrue("Chosen move $chosen must be in legal set $legalIds", legalIds.contains(chosen))
            }
        }
    }

    @Test
    fun testHardBotPrioritizesCapturingOpponent() {
        // Token 0 can capture Red on next tile
        // Token 1 can just move forward safely without capture
        val botTokens = listOf(
            // Token 0 at step 38 (track index: (13 + 38) % 52 = 51)
            Token(id = 0, color = PlayerColor.GREEN, state = TokenState.TRACK, stepsTraveled = 38),
            // Token 1 at step 10
            Token(id = 1, color = PlayerColor.GREEN, state = TokenState.TRACK, stepsTraveled = 10)
        )
        val botPlayer = Player(
            id = 1,
            name = "Bot Titan",
            color = PlayerColor.GREEN,
            tokens = botTokens,
            isBot = true,
            botDifficulty = BotDifficulty.HARD
        )

        // Human Red piece at track index 0 (safe star is at 0, so let's put it on an unsafe tile like 1!)
        // Green token 0 at step 39: (13 + 39) % 52 = 0. If token 0 is at step 39 and roll is 1, it lands on (13 + 40) % 52 = 1.
        // Index 1 is unsafe!
        val greenToken0 = Token(id = 0, color = PlayerColor.GREEN, state = TokenState.TRACK, stepsTraveled = 39)
        val greenToken1 = Token(id = 1, color = PlayerColor.GREEN, state = TokenState.TRACK, stepsTraveled = 10)

        // Red piece is at track index 1 (stepsTraveled = 1 for Red, index = 1, which is not a safe star)
        val redPiece = Token(id = 0, color = PlayerColor.RED, state = TokenState.TRACK, stepsTraveled = 1)
        val redPlayer = Player(id = 0, name = "Red", color = PlayerColor.RED, tokens = listOf(redPiece))

        val updatedBotPlayer = botPlayer.copy(tokens = listOf(greenToken0, greenToken1))

        val state = GameState(
            players = listOf(redPlayer, updatedBotPlayer),
            currentPlayerIndex = 1,
            diceValue = 1,
            isWaitingForRoll = false,
            movableTokenIds = setOf(0, 1)
        )

        val chosen = LudoBotAI.chooseMove(updatedBotPlayer, state, setOf(0, 1))
        // Hard bot must choose token 0 because it captures Red!
        assertEquals("Hard bot must select token 0 to execute capture", 0, chosen)
    }

    @Test
    fun testHardBotPrioritizesFinishingPiece() {
        // Token 0 can reach finish goal on roll 2
        val homeToken = Token(id = 0, color = PlayerColor.GREEN, state = TokenState.HOME_STRETCH, homeStep = 4)
        // Token 1 is on track
        val trackToken = Token(id = 1, color = PlayerColor.GREEN, state = TokenState.TRACK, stepsTraveled = 10)

        val botPlayer = Player(
            id = 1,
            name = "Bot Titan",
            color = PlayerColor.GREEN,
            tokens = listOf(homeToken, trackToken),
            isBot = true,
            botDifficulty = BotDifficulty.HARD
        )
        val human = Player(id = 0, name = "Human", color = PlayerColor.RED)

        val state = GameState(
            players = listOf(human, botPlayer),
            currentPlayerIndex = 1,
            diceValue = 2,
            isWaitingForRoll = false,
            movableTokenIds = setOf(0, 1)
        )

        val chosen = LudoBotAI.chooseMove(botPlayer, state, setOf(0, 1))
        assertEquals("Hard bot must choose token 0 to finish into the goal", 0, chosen)
    }

    @Test
    fun testComputeHopPathAccuracy() {
        val redToken = Token(id = 0, color = PlayerColor.RED, state = TokenState.TRACK, stepsTraveled = 10)
        val hopPath = BoardCoordinates.computeHopPath(redToken, roll = 3)

        // Must have 4 coordinates: start, step 1, step 2, step 3
        assertEquals(4, hopPath.size)
        assertEquals(BoardCoordinates.TRACK_TILES[10], hopPath[0])
        assertEquals(BoardCoordinates.TRACK_TILES[11], hopPath[1])
        assertEquals(BoardCoordinates.TRACK_TILES[12], hopPath[2])
        assertEquals(BoardCoordinates.TRACK_TILES[13], hopPath[3])
    }
}
