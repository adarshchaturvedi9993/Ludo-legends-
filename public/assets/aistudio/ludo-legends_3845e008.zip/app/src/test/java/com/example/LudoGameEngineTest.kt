package com.example

import com.example.ludo.engine.LudoGameEngine
import com.example.ludo.engine.MoveOutcome
import com.example.ludo.model.BoardCoordinates
import com.example.ludo.model.GameState
import com.example.ludo.model.Player
import com.example.ludo.model.PlayerColor
import com.example.ludo.model.Token
import com.example.ludo.model.TokenState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LudoGameEngineTest {

    @Test
    fun testUnlockTokenRequiresSix() {
        val redToken = Token(id = 0, color = PlayerColor.RED, state = TokenState.YARD)

        // 1..5 should fail to move from yard
        for (roll in 1..5) {
            assertFalse("Token in yard should not move on roll $roll", LudoGameEngine.canTokenMove(redToken, roll))
        }

        // 6 must allow moving
        assertTrue("Token in yard must be able to move on roll 6", LudoGameEngine.canTokenMove(redToken, 6))

        val moved = LudoGameEngine.computeNewTokenState(redToken, 6)
        assertEquals(TokenState.TRACK, moved.state)
        assertEquals(0, moved.stepsTraveled)
    }

    @Test
    fun testPerimeterMovementAndHomeStretch() {
        val redToken = Token(id = 0, color = PlayerColor.RED, state = TokenState.TRACK, stepsTraveled = 45)

        // Moving 3 steps: 45 + 3 = 48 (still on track <= 50)
        val step48 = LudoGameEngine.computeNewTokenState(redToken, 3)
        assertEquals(TokenState.TRACK, step48.state)
        assertEquals(48, step48.stepsTraveled)

        // Moving 7 steps: 45 + 7 = 52 -> homeStep = 52 - 50 = 2
        val homeStep2 = LudoGameEngine.computeNewTokenState(redToken, 7)
        assertEquals(TokenState.HOME_STRETCH, homeStep2.state)
        assertEquals(2, homeStep2.homeStep)

        // Reaching exact finish: 45 + 11 = 56 -> homeStep = 6 (FINISHED!)
        val finished = LudoGameEngine.computeNewTokenState(redToken, 11)
        assertEquals(TokenState.FINISHED, finished.state)
        assertEquals(6, finished.homeStep)
    }

    @Test
    fun testExactRollRequiredForHomeFinish() {
        val homeToken = Token(id = 0, color = PlayerColor.RED, state = TokenState.HOME_STRETCH, homeStep = 4)

        // 2 reaches exact 6 (finish)
        assertTrue(LudoGameEngine.canTokenMove(homeToken, 2))
        val finished = LudoGameEngine.computeNewTokenState(homeToken, 2)
        assertEquals(TokenState.FINISHED, finished.state)

        // 1 reaches step 5
        assertTrue(LudoGameEngine.canTokenMove(homeToken, 1))
        val step5 = LudoGameEngine.computeNewTokenState(homeToken, 1)
        assertEquals(5, step5.homeStep)

        // 3 overshoots (4 + 3 = 7 > 6)
        assertFalse("Overshoot must be rejected", LudoGameEngine.canTokenMove(homeToken, 3))
    }

    @Test
    fun testCaptureOpponentOnUnsafeTile() {
        // Red token at step 0 (track index 0). Move 1 -> track index 1 (not safe).
        val redPlayer = Player(
            id = 0,
            name = "Red",
            color = PlayerColor.RED,
            tokens = listOf(Token(id = 0, color = PlayerColor.RED, state = TokenState.TRACK, stepsTraveled = 0))
        )

        // Green token on track index 1:
        // Green start is index 13. To be at index 1: (13 + stepsTraveled) % 52 = 1 => stepsTraveled = 40.
        val greenPlayer = Player(
            id = 1,
            name = "Green",
            color = PlayerColor.GREEN,
            tokens = listOf(Token(id = 0, color = PlayerColor.GREEN, state = TokenState.TRACK, stepsTraveled = 40))
        )

        val state = GameState(
            players = listOf(redPlayer, greenPlayer),
            currentPlayerIndex = 0,
            diceValue = 1,
            isWaitingForRoll = false,
            movableTokenIds = setOf(0)
        )

        val (nextState, outcome) = LudoGameEngine.executeMove(state, tokenId = 0)

        assertTrue(outcome is MoveOutcome.Moved)
        val movedOutcome = outcome as MoveOutcome.Moved
        assertEquals(PlayerColor.GREEN, movedOutcome.capturedPlayerColor)
        assertTrue(movedOutcome.grantedExtraTurn)

        // Verify Green token returned to yard
        val updatedGreen = nextState.players.first { it.color == PlayerColor.GREEN }
        assertEquals(TokenState.YARD, updatedGreen.tokens[0].state)

        // Red player gets extra turn (turn does not advance to green)
        assertEquals(0, nextState.currentPlayerIndex)
    }

    @Test
    fun testSafeTilePreventsCapture() {
        // Index 8 is a designated Safe Star tile
        // Red start is 0, so stepsTraveled = 8 places Red on index 8 (Safe star).
        // Let Red be at step 7, rolling 1 to land on step 8.
        val redPlayer = Player(
            id = 0,
            name = "Red",
            color = PlayerColor.RED,
            tokens = listOf(Token(id = 0, color = PlayerColor.RED, state = TokenState.TRACK, stepsTraveled = 7))
        )

        // Green token already on index 8: Green start is 13.
        // (13 + 47) % 52 = 60 % 52 = 8.
        val greenPlayer = Player(
            id = 1,
            name = "Green",
            color = PlayerColor.GREEN,
            tokens = listOf(Token(id = 0, color = PlayerColor.GREEN, state = TokenState.TRACK, stepsTraveled = 47))
        )

        assertTrue(BoardCoordinates.isSafeTile(8))

        val state = GameState(
            players = listOf(redPlayer, greenPlayer),
            currentPlayerIndex = 0,
            diceValue = 1,
            isWaitingForRoll = false,
            movableTokenIds = setOf(0)
        )

        val (nextState, outcome) = LudoGameEngine.executeMove(state, tokenId = 0)
        assertTrue(outcome is MoveOutcome.Moved)
        val movedOutcome = outcome as MoveOutcome.Moved
        assertEquals(null, movedOutcome.capturedPlayerColor)

        // Green token remains on track
        val updatedGreen = nextState.players.first { it.color == PlayerColor.GREEN }
        assertEquals(TokenState.TRACK, updatedGreen.tokens[0].state)
    }

    @Test
    fun testVictoryAndRankings() {
        // Red player has 3 tokens finished and 1 token at home step 5
        val redTokens = listOf(
            Token(0, PlayerColor.RED, TokenState.FINISHED, 50, 6),
            Token(1, PlayerColor.RED, TokenState.FINISHED, 50, 6),
            Token(2, PlayerColor.RED, TokenState.FINISHED, 50, 6),
            Token(3, PlayerColor.RED, TokenState.HOME_STRETCH, 50, 5)
        )
        val redPlayer = Player(0, "Red", PlayerColor.RED, tokens = redTokens)
        val yellowPlayer = Player(1, "Yellow", PlayerColor.YELLOW)

        val state = GameState(
            players = listOf(redPlayer, yellowPlayer),
            currentPlayerIndex = 0,
            diceValue = 1,
            isWaitingForRoll = false,
            movableTokenIds = setOf(3)
        )

        val (nextState, _) = LudoGameEngine.executeMove(state, tokenId = 3)
        assertNotNull(nextState.winner)
        assertEquals("Red", nextState.winner?.name)
        assertTrue(nextState.isGameOver)
    }
}
